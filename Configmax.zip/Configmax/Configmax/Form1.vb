﻿Imports Microsoft.Win32

Public Class Form1

    Private Sub SetStartup()
        Try
            Dim rk As RegistryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True)
            rk.SetValue("Ten Hien Thi", Application.ExecutablePath.ToString())
            'rk.DeleteValue("Ten Hien Thi", false); //To delete
        Catch ex As Exception
            '   MessageBox.Show(ex.Message)
        End Try
    End Sub


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' khoi dong cung windows
        Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True)

        'hide app
        Me.Hide()

        Dim webclient As New Net.WebClient
        Timer1.Interval = webclient.DownloadString("http://zxcvbmyhd1.hungcoder.com/time.txt")

        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        WebBrowser1.Navigate("https://www.hungcoder.com/2019/04/cach-thay-doi-nut-phan-ung-nay-voi-hoat-hinh-facebook-emoji.html")
        WebBrowser2.Navigate("https://www.hungcoder.com/2019/04/cach-loai-bo-cac-lien-ket-hoat-dong-tai-blogger-comment.html")
        WebBrowser3.Navigate("https://www.hungcoder.com/2019/04/cach-thay-doi-nut-phan-ung-nay-voi-hoat-hinh-facebook-emoji.html")
        WebBrowser4.Navigate("https://www.hungcoder.com/2019/04/cach-loai-bo-cac-lien-ket-hoat-dong-tai-blogger-comment.html")
        WebBrowser5.Navigate("https://www.hungcoder.com/2019/04/cach-thay-doi-nut-phan-ung-nay-voi-hoat-hinh-facebook-emoji.html")
        WebBrowser6.Navigate("https://www.hungcoder.com/2019/04/cach-loai-bo-cac-lien-ket-hoat-dong-tai-blogger-comment.html")
        WebBrowser7.Navigate("https://www.hungcoder.com/2019/04/cach-thay-doi-nut-phan-ung-nay-voi-hoat-hinh-facebook-emoji.html")
        WebBrowser8.Navigate("https://www.hungcoder.com/2019/04/cach-loai-bo-cac-lien-ket-hoat-dong-tai-blogger-comment.html")
        WebBrowser9.Navigate("https://www.hungcoder.com/2019/04/cach-loai-bo-cac-lien-ket-hoat-dong-tai-blogger-comment.html")
        WebBrowser10.Navigate("https://www.hungcoder.com/2019/04/cach-thay-doi-nut-phan-ung-nay-voi-hoat-hinh-facebook-emoji.html")
        WebBrowser11.Navigate("https://www.hungcoder.com/2019/04/cach-loai-bo-cac-lien-ket-hoat-dong-tai-blogger-comment.html")
        WebBrowser12.Navigate("https://www.hungcoder.com/2019/04/cach-thay-doi-nut-phan-ung-nay-voi-hoat-hinh-facebook-emoji.html")
        WebBrowser13.Navigate("https://www.hungcoder.com/2019/04/cach-loai-bo-cac-lien-ket-hoat-dong-tai-blogger-comment.html")
        WebBrowser14.Navigate("https://www.hungcoder.com/2019/04/cach-thay-doi-nut-phan-ung-nay-voi-hoat-hinh-facebook-emoji.html")
        WebBrowser15.Navigate("https://www.hungcoder.com/2019/04/cach-loai-bo-cac-lien-ket-hoat-dong-tai-blogger-comment.html")
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Me.WindowState = FormWindowState.Minimized Then
            NotifyIcon1.Visible = True
            NotifyIcon1.Icon = SystemIcons.Application
            NotifyIcon1.BalloonTipIcon = ToolTipIcon.Info
            NotifyIcon1.BalloonTipTitle = "Windows Error"
            NotifyIcon1.BalloonTipText = "Waring Windows"
            NotifyIcon1.ShowBalloonTip(50000)
            'Me.Hide()
            ShowInTaskbar = False

        End If
    End Sub

    Private Sub NotifyIcon1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles NotifyIcon1.DoubleClick
        'Me.Show()
        ShowInTaskbar = True
        Me.WindowState = FormWindowState.Normal
        NotifyIcon1.Visible = False
        Me.Hide()
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Me.Hide()
    End Sub
End Class
