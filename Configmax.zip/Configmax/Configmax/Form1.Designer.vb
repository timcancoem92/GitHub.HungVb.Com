﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser2 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser3 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser4 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser5 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser6 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser7 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser8 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser9 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser10 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser11 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser12 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser13 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser14 = New System.Windows.Forms.WebBrowser()
        Me.WebBrowser15 = New System.Windows.Forms.WebBrowser()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Location = New System.Drawing.Point(12, 12)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.ScriptErrorsSuppressed = True
        Me.WebBrowser1.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser1.TabIndex = 0
        '
        'WebBrowser2
        '
        Me.WebBrowser2.Location = New System.Drawing.Point(268, 12)
        Me.WebBrowser2.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser2.Name = "WebBrowser2"
        Me.WebBrowser2.ScriptErrorsSuppressed = True
        Me.WebBrowser2.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser2.TabIndex = 1
        '
        'WebBrowser3
        '
        Me.WebBrowser3.Location = New System.Drawing.Point(524, 12)
        Me.WebBrowser3.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser3.Name = "WebBrowser3"
        Me.WebBrowser3.ScriptErrorsSuppressed = True
        Me.WebBrowser3.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser3.TabIndex = 2
        '
        'WebBrowser4
        '
        Me.WebBrowser4.Location = New System.Drawing.Point(780, 12)
        Me.WebBrowser4.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser4.Name = "WebBrowser4"
        Me.WebBrowser4.ScriptErrorsSuppressed = True
        Me.WebBrowser4.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser4.TabIndex = 3
        '
        'WebBrowser5
        '
        Me.WebBrowser5.Location = New System.Drawing.Point(1036, 12)
        Me.WebBrowser5.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser5.Name = "WebBrowser5"
        Me.WebBrowser5.ScriptErrorsSuppressed = True
        Me.WebBrowser5.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser5.TabIndex = 4
        '
        'WebBrowser6
        '
        Me.WebBrowser6.Location = New System.Drawing.Point(1039, 278)
        Me.WebBrowser6.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser6.Name = "WebBrowser6"
        Me.WebBrowser6.ScriptErrorsSuppressed = True
        Me.WebBrowser6.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser6.TabIndex = 9
        '
        'WebBrowser7
        '
        Me.WebBrowser7.Location = New System.Drawing.Point(783, 278)
        Me.WebBrowser7.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser7.Name = "WebBrowser7"
        Me.WebBrowser7.ScriptErrorsSuppressed = True
        Me.WebBrowser7.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser7.TabIndex = 8
        '
        'WebBrowser8
        '
        Me.WebBrowser8.Location = New System.Drawing.Point(527, 278)
        Me.WebBrowser8.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser8.Name = "WebBrowser8"
        Me.WebBrowser8.ScriptErrorsSuppressed = True
        Me.WebBrowser8.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser8.TabIndex = 7
        '
        'WebBrowser9
        '
        Me.WebBrowser9.Location = New System.Drawing.Point(271, 278)
        Me.WebBrowser9.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser9.Name = "WebBrowser9"
        Me.WebBrowser9.ScriptErrorsSuppressed = True
        Me.WebBrowser9.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser9.TabIndex = 6
        '
        'WebBrowser10
        '
        Me.WebBrowser10.Location = New System.Drawing.Point(15, 278)
        Me.WebBrowser10.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser10.Name = "WebBrowser10"
        Me.WebBrowser10.ScriptErrorsSuppressed = True
        Me.WebBrowser10.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser10.TabIndex = 5
        '
        'WebBrowser11
        '
        Me.WebBrowser11.Location = New System.Drawing.Point(1039, 534)
        Me.WebBrowser11.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser11.Name = "WebBrowser11"
        Me.WebBrowser11.ScriptErrorsSuppressed = True
        Me.WebBrowser11.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser11.TabIndex = 14
        '
        'WebBrowser12
        '
        Me.WebBrowser12.Location = New System.Drawing.Point(780, 534)
        Me.WebBrowser12.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser12.Name = "WebBrowser12"
        Me.WebBrowser12.ScriptErrorsSuppressed = True
        Me.WebBrowser12.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser12.TabIndex = 13
        '
        'WebBrowser13
        '
        Me.WebBrowser13.Location = New System.Drawing.Point(527, 534)
        Me.WebBrowser13.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser13.Name = "WebBrowser13"
        Me.WebBrowser13.ScriptErrorsSuppressed = True
        Me.WebBrowser13.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser13.TabIndex = 12
        '
        'WebBrowser14
        '
        Me.WebBrowser14.Location = New System.Drawing.Point(271, 534)
        Me.WebBrowser14.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser14.Name = "WebBrowser14"
        Me.WebBrowser14.ScriptErrorsSuppressed = True
        Me.WebBrowser14.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser14.TabIndex = 11
        '
        'WebBrowser15
        '
        Me.WebBrowser15.Location = New System.Drawing.Point(12, 534)
        Me.WebBrowser15.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser15.Name = "WebBrowser15"
        Me.WebBrowser15.ScriptErrorsSuppressed = True
        Me.WebBrowser15.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser15.TabIndex = 10
        '
        'Timer1
        '
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "Windows Messenger !"
        Me.NotifyIcon1.Visible = True
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 10
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(187, 0)
        Me.Controls.Add(Me.WebBrowser11)
        Me.Controls.Add(Me.WebBrowser12)
        Me.Controls.Add(Me.WebBrowser13)
        Me.Controls.Add(Me.WebBrowser14)
        Me.Controls.Add(Me.WebBrowser15)
        Me.Controls.Add(Me.WebBrowser6)
        Me.Controls.Add(Me.WebBrowser7)
        Me.Controls.Add(Me.WebBrowser8)
        Me.Controls.Add(Me.WebBrowser9)
        Me.Controls.Add(Me.WebBrowser10)
        Me.Controls.Add(Me.WebBrowser5)
        Me.Controls.Add(Me.WebBrowser4)
        Me.Controls.Add(Me.WebBrowser3)
        Me.Controls.Add(Me.WebBrowser2)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Windows Error"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser2 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser3 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser4 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser5 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser6 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser7 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser8 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser9 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser10 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser11 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser12 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser13 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser14 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser15 As System.Windows.Forms.WebBrowser
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents Timer2 As System.Windows.Forms.Timer

End Class
